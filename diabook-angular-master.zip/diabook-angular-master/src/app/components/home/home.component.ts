import {Component, OnInit} from '@angular/core';
import {Patient} from '../../models/Patient';
import {DataService} from '../../services/data.service';
import {NavigationExtras, Router} from '@angular/router';
import {SharedService} from '../../services/shared.service';
import {MyCache} from '../../utils/MyCache';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  patients: Patient[];
  table_display = true;
  dropdown_items: any[] = [];
  deleteParams: {ptId: number, drId: number};


  patientCount: number = -1;

  constructor(private dataService: DataService,
              private router: Router,
              private sharedService: SharedService) {
  }

  ngOnInit() {
    this.patients = [];
    this.loadPatients();
  }

  private loadPatients(): void {
    this.dataService.get('/api/getPatientsByDr?drId=1').subscribe((data) => {
      this.parsePatientsData(data);
    });
  }

  private parsePatientsData(data: any): void {
    for (let index = 0; index < data.length; index++) {
      let patient = <Patient> {};
      patient = data[index];
      this.patients.push(patient);
    }
    MyCache.savePatients(this.patients);
    this.patientCount = this.patients.length;
    console.log(this.patients);
    this.loadTable();
  }

  private loadTable(): void {
    this.table_display = false;
    setTimeout(() => this.table_display = true, 0);
  }

  selectPatient(id: number) {
    console.log('HERE');
    this.router.navigate([`/patient-record/${id}`]);
  }

  getDropDownItems(ptId: number) {
    return [
      {
        label: 'Update',
        icon: 'fa fa-refresh',
        command: () => {
          this.update(ptId);
        }
      },
      {
        label: 'Delete', icon: 'fa fa-close', command: () => {
          this.delete(ptId);
        }
      }
    ];
  }

  update(ptId) {
    console.log('PT ID - ' + ptId + ' UPDATE');
    this.router.navigate([`/update-patient/${ptId}`]);
  }

  delete(ptId) {
    this.deleteParams = {"ptId" : ptId, "drId" : 1};
    this.dataService.post('/api/deletePatientByDr', this.deleteParams).subscribe(
      (data) => {
        if(data == 'Patient Deleted') {
          console.log("deleted successfully");
        }
      }
    )};
}

