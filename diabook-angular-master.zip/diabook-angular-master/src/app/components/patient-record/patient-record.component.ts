import {Component, OnInit} from '@angular/core';
import {SharedService} from '../../services/shared.service';
import {Patient} from '../../models/Patient';
import {ActivatedRoute, Router} from '@angular/router';
import {Prescription} from '../../models/prescription';
import {DataService} from '../../services/data.service';
import {MyCache} from '../../utils/MyCache';

@Component({
  selector: 'app-patient-record',
  templateUrl: './patient-record.component.html',
  styleUrls: ['./patient-record.component.css']
})
export class PatientRecordComponent implements OnInit {


  patient: Patient;
  prescriptions: Prescription[];
  currentShowingPrescription: Prescription = <Prescription> {};
  indexPosition: string = '';

  constructor(private sharedService: SharedService,
              private route: ActivatedRoute,
              private router: Router,
              private dataService: DataService) {
  }

  ngOnInit() {

    this.route.params.subscribe((data) => {
      this.patient = MyCache.getPatientById(data.id);
      this.prescriptions = [];
      this.loadPrescriptions();
    });


  }

  private loadPrescriptions(): void {
    this.dataService.get(`api/getAllPrescriptionsByDrAndPt?drId=1&ptId=${this.patient.ptId}`).subscribe((data) => {
      this.parsePrescriptionsData(data);
    });
  }

  private parsePrescriptionsData(data: any): void {
    for (let i = 0; i < data.length; i++) {
      let prescription = <Prescription> {};
      prescription = data[i];
      this.prescriptions.push(prescription);
    }
    this.currentShowingPrescription = this.prescriptions[0];
    this.indexPosition = 'FIRST';
    console.log(this.prescriptions);
  }

  showPrescription(p: Prescription) {
    this.currentShowingPrescription = p;
    const index = this.prescriptions.findIndex(each => each.rxId === this.currentShowingPrescription.rxId);
    if (index === 0) this.indexPosition = 'FIRST';
    if (index === this.prescriptions.length - 1) this.indexPosition = 'LAST';
  }

  changePrescription(emittedObject: any) {
    const id = emittedObject.id;
    const type = emittedObject.type;
    let index: number = this.prescriptions.findIndex(each => each.rxId === id);
    if (type === 'NEXT') {
      if (index === this.prescriptions.length - 1) return;
      this.currentShowingPrescription = this.prescriptions[index + 1];
      if (index === this.prescriptions.length - 2) this.indexPosition = 'LAST';
    }
    else {
      if (index === 0) return;
      this.currentShowingPrescription = this.prescriptions[index - 1];
      if (index === 1) this.indexPosition = 'FIRST';
    }
  }

  newPrescription() {
    this.router.navigate([`/prescription/${this.patient.ptId}`]);
  }
}

