import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Prescription} from "../../models/prescription";
import {Router} from '@angular/router';
import {SharedService} from '../../services/shared.service';

@Component({
  selector: 'app-patient-record-prescription',
  templateUrl: './patient-record-prescription.component.html',
  styleUrls: ['./patient-record-prescription.component.css']
})
export class PatientRecordPrescriptionComponent implements OnInit {

  constructor(private sharedService: SharedService, private router: Router) { }

  @Input('prescription') prescription: Prescription;
  @Input('indexPosition') indexPosition: string;
  @Output('changePrescriptionEmitter') emitter: EventEmitter<any> = new EventEmitter();

  ngOnInit() {
    this.prescription = <Prescription> {};
    console.log(this.prescription);
  }

  showPreviousPrescription() {
    this.emitter.emit({
      type: 'PREV',
      id: this.prescription.rxId
    });
  }

  showNextPrescription() {
    this.emitter.emit({
      type: 'NEXT',
      id: this.prescription.rxId
    });
  }

  editPrescription() {
      this.sharedService.setPrescription(this.prescription);
      console.log("CHECK HEREE");
      console.log(this.prescription);
      this.router.navigateByUrl(`prescription/${this.prescription.ptId}`);
  }
}
