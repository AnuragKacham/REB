import {Component, OnInit} from '@angular/core';
import {Patient} from '../../models/Patient';
import {DataService} from '../../services/data.service';
import {ActivatedRoute} from '@angular/router';
import {MyCache} from '../../utils/MyCache';

@Component({
  selector: 'app-new-patient',
  templateUrl: './new-patient.component.html',
  styleUrls: ['./new-patient.component.css']
})
export class NewPatientComponent implements OnInit {
  patient: Patient;
  insertStatus: boolean;
  updateStatus: boolean;
  gender_dropdown: any[] = [];
  ptId: number;
  checkEditStatus: boolean = false;

  constructor(private dataService: DataService,
              private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.insertStatus = false;
    this.updateStatus = false;
    // this.patient = <Patient> {};
    this.checkIfUpdate();
    this.loadDefaults();

  }

  private checkIfUpdate() {
    this.ptId = this.route.snapshot.params['id'];
    if(this.ptId) {
      this.patient = MyCache.getPatientById(this.ptId);
      this.checkEditStatus = true;
    } else {
      this.patient = <Patient> {};
      this.checkEditStatus =  false;
    }
  }

  loadDefaults() {
    this.gender_dropdown = [];
    this.gender_dropdown.push({label: 'Select', value: null});
    this.gender_dropdown.push({label: 'Male', value: 'Male'});
    this.gender_dropdown.push({label: 'Female', value: 'Female'});
  }

  public addPatient() {
    this.dataService.post('/api/postPatientByDr', this.patient).subscribe(
      (data) => {
        if(data == 'Patient Added') {this.insertStatus = true;}
      }
    )};

  public updatePatient() {
    this.dataService.post('/api/updatePatientByDr', this.patient).subscribe(
      (data) => {
        if(data == 'Patient Updated') {this.updateStatus = true;}
      }
    )
  }

  public dismissStatus() {
    this.insertStatus = false;
  }

  public resetForm() {
    this.patient = <Patient> {};
  }

}
