import {Component, OnInit} from '@angular/core';
import {Prescription} from '../../models/prescription';
import {Investigation} from '../../models/investigation';
import {Medication} from '../../models/medication';
import {PrescriptionService} from '../../services/prescription.service';
import {Patient} from '../../models/Patient';
import {SharedService} from '../../services/shared.service';
import {Objects} from '../../utils/Objects';
import {MyCache} from '../../utils/MyCache';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-prescription',
  templateUrl: './prescription.component.html',
  styleUrls: ['./prescription.component.css']
})
export class PrescriptionComponent implements OnInit {

  public prescription: Prescription;
  public allMedications: Medication[] = [];
  med_time_dropdown: any[] = [];
  med_food_dropdown: any [] = [];
  allInvestigations: Investigation[] = [];
  autoCompleteResults: string[] = [];
  investigationsCompleteResults: Investigation[] = [];
  investigationsCommentsResults: string[] = [];
  medicationField: string = 'dgName';
  investigationField: string = 'ltName';
  bufferInvComments: Investigation[] = [];

  patient: Patient;

  constructor(private prescriptionservice: PrescriptionService,
              private route: ActivatedRoute,
              private sharedService: SharedService) {
  }

  ngOnInit() {
    // this.patient = MyCache.getPatientById();
    this.route.params.subscribe((data) => {
      this.patient = MyCache.getPatientById(data.id);
    });
    // console.log('Selected Patient : ');
    // console.log(this.patient);
    this.prescription = Objects.createDefaultPrescription();
    this.allMedications.push(<Medication> {});
    this.allInvestigations.push(<Investigation> {});
    this.checkIfEdit();
    this.loadData();
  }

  private checkIfEdit() {
    let cachedPrescription = this.sharedService.getPrescription();
    // console.log('CACHE: ');
    // console.log(cachedPrescription);
    if (cachedPrescription) {
      this.prescription = cachedPrescription;
      this.allMedications = cachedPrescription.prescriptionMedications;
      this.allInvestigations = cachedPrescription.prescriptionInvestigations;
      console.log(this.allInvestigations);
      this.medicationField = null;
      this.investigationField = null;
    }
  }

  public loadData() {
    // console.log('prescription:', this.prescription);
    // console.log('Medications:', this.allMedications);

    this.med_food_dropdown = [];
    this.med_time_dropdown = [];

    this.med_food_dropdown.push({label: 'Before Food', value: 'Before Food'});
    this.med_food_dropdown.push({label: 'After Food', value: 'After Food'});

    this.med_time_dropdown.push({label: 'Morning', value: 'Morning'});
    this.med_time_dropdown.push({label: 'After Noon', value: 'After Noon'});
    this.med_time_dropdown.push({label: 'Evening', value: 'Evening'});
    this.med_time_dropdown.push({label: 'Night', value: 'Night'});
    this.med_time_dropdown.push({label: 'Bed Time', value: 'Bed Time'});
  }

  addMedicine() {
    this.allMedications.push(<Medication> {});
  }

  deleteMedicine(i) {
    if (this.allMedications.length === 1) {
      return;
    }
    this.allMedications.splice(i, 1);
  }

  addInvestigation() {
    this.allInvestigations.push(<Investigation> {});
  }

  deleteInvestigation(i) {
    if (this.allInvestigations.length === 1) {
      return;
    }
    this.allInvestigations.splice(i, 1);
  }

  queryForAutoComplete(event) {
    // console.log(event);
    this.medicationField = 'dgName';
    this.prescriptionservice.get('/api/getDrugs?dgName=' + event.query).subscribe((data) => {
      this.autoCompleteResults = data;
    });
  }

  investigationsAutoComplete(event) {
    // console.log(event);
    this.investigationField = 'ltName';
    this.prescriptionservice.get('/api/getLabTests?ltName=' + event.query).subscribe((data) => {
      this.investigationsCompleteResults = data;
    });
  }


  resetPrescription() {
    this.prescription = <Prescription> {};
    this.allMedications = [];
    this.allInvestigations = [];
    this.allMedications.push(<Medication> {});
    this.allInvestigations.push(<Investigation> {});
    this.loadData();
  }

  public getReferences() {
    const url = '';
    const params = {};
    this.prescriptionservice.postData(url, params).subscribe((data) => {
      console.log('Result:', data);
    });
  }

  public submitPrescription() {
    this.allMedications = this.allMedications.map(each => {
      each.medName = each.medName.dgName;
      return each;
    });
    this.allInvestigations = this.allInvestigations.map(each => {
      each.invName = each.invName.ltName;
      return each;
    });
    this.prescription.prescriptionMedications = this.allMedications;
    this.prescription.prescriptionInvestigations = this.allInvestigations;

    // this.prescription.drId = 1;
    // this.prescription.ptId = 1;

    const url = '/api/postPrescriptionByDrPt';
    this.prescriptionservice.postData(url, this.prescription).subscribe((data) => {
      console.log('**************************', data);
    });
  }


}
