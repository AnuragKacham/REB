import {Routes} from "@angular/router";
import {PrescriptionComponent} from "./components/prescription/prescription.component";
import {HomeComponent} from './components/home/home.component';
import {PatientRecordComponent} from './components/patient-record/patient-record.component';
import {NewPatientComponent} from './components/new-patient/new-patient.component';

/**
 * Created by vesarath on 11/28/2017.
 */

export const appRoutes: Routes = [
  {path: 'prescription/:id', component: PrescriptionComponent},
  {path: 'prescription', component: PrescriptionComponent},
  {path: 'home', component: HomeComponent},
  {path: 'patient-record/:id', component: PatientRecordComponent},
  {path: 'patient-record', component: PatientRecordComponent},
  {path: 'new-patient', component: NewPatientComponent},
  {path: 'update-patient/:id', component: NewPatientComponent},
  // otherwise redirect to home
  {path: '**', redirectTo: 'home'}
];
