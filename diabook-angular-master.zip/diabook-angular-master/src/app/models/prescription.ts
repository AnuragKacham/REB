import {Medication} from "./medication";
import {Investigation} from './investigation';

export interface Prescription {
  drId: number;
  ptId: number;
  rxId: number;
  rxHeight: string;
  rxWeight: string;
  rxBmi: string;
  rxBloodPressure: string;
  body_temp: string;
  rxWaistCircumference: string;
  rxHipCircumference: string;
  rxWcircumHt: string;
  rxIdealBodyWeight: string;
  rxTargetedBodyWeight: string;
  rxAdvisedCaloriesDay: string;
  rxComplaints: string;
  rxObservations: string;
  prescriptionInvestigations: Investigation[];
  rxDiagnosis: string;
  prescriptionMedications: Medication[];
  rxComments: string;
  rxReferredTo: string;
  rxReferredComments: string;
  rxNextVisitDate: Date;
  rxNextVisitComments: string;
}
