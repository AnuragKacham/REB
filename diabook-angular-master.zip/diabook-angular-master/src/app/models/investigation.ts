export interface Investigation {
  invId: number;
  drId: number;
  ptId: number;
  rxId: number;
  invName: any;
  invComments: string[];
}
