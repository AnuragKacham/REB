/**
 * Created by vesarath on 11/28/2017.
 */
export interface Patient {
  ptId: number;
  ptFirstName: string;
  ptLastName: string;
  ptPhone: string;
  ptEmail: string;
  ptAddress: string;
  ptDob: string;
  ptGender: string;
  ptOccupation: string;
  ptMaritalStatus: string;
  ptEducation: string;
}
