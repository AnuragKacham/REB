export interface Medication {
  medId: number;
  drId: number;
  ptId: number;
  rxId: number;
  medName: any;
  medQuantity: number;
  medFood: string;
  medTimeList: string[];
}
