import {AdminModule} from './admin/admin.module';
import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {AppComponent} from './app.component';
import {StarterComponent} from './starter/starter.component';
import {StarterHeaderComponent} from './starter/starter-header/starter-header.component';
import {StarterLeftSideComponent} from './starter/starter-left-side/starter-left-side.component';
import {StarterFooterComponent} from './starter/starter-footer/starter-footer.component';
import {StarterControlSidebarComponent} from './starter/starter-control-sidebar/starter-control-sidebar.component';
import {HashLocationStrategy, LocationStrategy} from '@angular/common';
import {RouterModule} from '@angular/router';
import {appRoutes} from './app.routing';
import {
  AutoCompleteModule, ButtonModule, CalendarModule, DataTableModule, DropdownModule, InputTextModule,
  MultiSelectModule, SplitButtonModule
} from 'primeng/primeng';
import {PrescriptionComponent} from './components/prescription/prescription.component';
import {FormsModule} from '@angular/forms';
import {PrescriptionService} from './services/prescription.service';
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {HomeComponent} from "./components/home/home.component";
import {DataService} from "./services/data.service";
import {HttpClientModule} from "@angular/common/http";
import {SharedService} from "./services/shared.service";
import {PatientRecordComponent} from './components/patient-record/patient-record.component';
import { PatientRecordPrescriptionComponent } from './components/patient-record-prescription/patient-record-prescription.component';
import {TableModule} from 'primeng/table';
import { NewPatientComponent } from './components/new-patient/new-patient.component';

@NgModule({
  declarations: [
    AppComponent,
    StarterComponent,
    StarterHeaderComponent,
    StarterLeftSideComponent,
    StarterFooterComponent,
    StarterControlSidebarComponent,
    PrescriptionComponent,
    HomeComponent,
    PatientRecordComponent,
    PatientRecordPrescriptionComponent,
    NewPatientComponent,
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    AdminModule,
    DataTableModule,
    FormsModule,
    DropdownModule,
    BrowserAnimationsModule,
    MultiSelectModule,
    CalendarModule,
    AutoCompleteModule,
    HttpClientModule,
    ButtonModule,
    TableModule,
    InputTextModule,
    SplitButtonModule
  ],
  providers: [{
    provide: LocationStrategy,
    useClass: HashLocationStrategy
  }],
  bootstrap:
    [StarterComponent]
})

export class AppModule {

}
