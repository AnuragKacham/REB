
import {Injectable} from "@angular/core";
import {Patient} from "../models/Patient";
import {Prescription} from '../models/prescription';

@Injectable({providedIn: 'root'})
export class SharedService {

  private selectedPrescription: Prescription;

  getPrescription(): Prescription {
    return this.selectedPrescription;
  }

  setPrescription(value: Prescription) {
    this.selectedPrescription = value;
  }

}
