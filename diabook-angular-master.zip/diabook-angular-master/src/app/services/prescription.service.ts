import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';
import {HttpHeaders} from "@angular/common/http";

@Injectable({providedIn: 'root'})
export class PrescriptionService {
  constructor(private http: HttpClient) {
  }

  public postData(url, params): Observable<any> {
    // const new_url = 'http://localhost:9000' + url;
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    console.log('Params: ', params);
    return this.http.post(url, params);
  }

  public get(url): Observable<any> {
    return this.http.get(url);
  }

}
