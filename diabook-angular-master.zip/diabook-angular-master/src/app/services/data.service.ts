
import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import {HttpClient} from "@angular/common/http";
import {HttpHeaders} from "@angular/common/http";

@Injectable({providedIn: 'root'})
export class DataService {

  constructor(private http: HttpClient) {}

  public get(url): Observable<any> {
    console.log('URL:', url);
    return this.http.get(url);
  }

  public post(url, params): any {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    console.log('Params: ', params);
    return this.http.post(url, params);

  }
}
