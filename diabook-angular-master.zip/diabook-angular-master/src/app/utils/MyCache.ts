import {Patient} from '../models/Patient';

export class MyCache {

  private static patientsMap = {};

  public static getPatientById(id: number): Patient {
    return MyCache.patientsMap[id];
  }

  public static savePatients(patient: Patient[]) {
    patient.forEach(each => {
      MyCache.patientsMap[each.ptId] = each;
    });
  }

}
