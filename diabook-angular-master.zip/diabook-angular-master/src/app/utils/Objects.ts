import {Prescription} from "../models/prescription";

export class Objects {
  static createDefaultPrescription(): Prescription {

    let obj = <Prescription> {};
    obj.rxNextVisitDate = new Date();
    obj.rxHeight = '1';
    obj.rxWeight = '1';
    obj.rxBmi = '1';
    obj.rxBloodPressure ='1';
    obj.body_temp = '1' ;
    obj.rxWaistCircumference = '1';
    obj.rxHipCircumference = '1';
    obj.rxWcircumHt = '1';
    obj.rxIdealBodyWeight = '1';
    obj.rxTargetedBodyWeight = '1';
    obj.rxAdvisedCaloriesDay = '1';
    obj.rxComplaints = '1';
    obj.rxObservations = '1';
    obj.prescriptionInvestigations = [];
    obj.rxDiagnosis = '1';
    obj.prescriptionMedications=[];
    obj.rxComments = '1';
    obj.rxReferredTo = '1';
    obj.rxReferredComments = '1';
    obj.rxNextVisitComments = '1';
    obj.drId = 1;
    obj.ptId = 1;
    return obj;
  }
}
