package com.docportal.diabook;


import com.docportal.diabook.repositories.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class CleanUpDataTest {

    @Autowired
    protected DoctorRepository doctorRepository;

    public void cleanUp() {
        doctorRepository.deleteAll();
    }
}
