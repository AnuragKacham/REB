package com.docportal.diabook.services;

import com.docportal.diabook.CleanUpDataTest;
import com.docportal.diabook.models.Doctor;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DoctorServiceImplTest  extends CleanUpDataTest {

    @Autowired
    private DoctorService doctorService;

    @Before
    public void cleanUp() {super.cleanUp();}

    @After
    public void tearDown() {}

    @Test
    public void testGetAllDoctors(){
        Doctor doctor1 = doctorService.createDoctor(Doctor.builder().name("Abhinav").email("abhi.4125@gmail.com").build());
        Doctor doctor2 = doctorService.createDoctor(Doctor.builder().name("Anvesh").email("bkanhevs22@gmail.com").build());

        List<Doctor> allDoctors = doctorService.getAllDoctors();
        assertEquals(2, allDoctors.size());
    }

    @Test
    public void testGetDoctorById(){
        Doctor doctor1 = doctorService.createDoctor(Doctor.builder().name("Abhinav").email("abhi.4125@gmail.com").build());

        Doctor doctorById = doctorService.getDoctorById(doctor1.getId());
        assertNotNull(doctorById);
        assertEquals((long)doctor1.getId(), (long)doctorById.getId());
        assertEquals("Abhinav", doctorById.getName());
        assertEquals("abhi.4125@gmail.com", doctorById.getEmail());
    }

    @Test
    public void testCreateDoctor(){
        Doctor doctor = doctorService.createDoctor(Doctor.builder().name("Abhinav").email("abhi.4125@gmail.com").build());

        assertNotNull(doctor);
        assertEquals("Abhinav", doctor.getName());
        assertEquals("abhi.4125@gmail.com", doctor.getEmail());
    }

    @Test
    public void testUpdateDoctor(){
        Doctor doctor = doctorService.createDoctor(Doctor.builder().name("Anvesh").email("abhi.4125@gmail.com").build());
        Doctor modified = doctorService.updateDoctor(doctor.getId(), Doctor.builder().name("Abhinav").email("labhinavkumar@yahoo.com").build());

        assertNotNull(modified);
        assertEquals(doctor.getId(), modified.getId());
        assertEquals("Abhinav", modified.getName());
        assertEquals("labhinavkumar@yahoo.com", modified.getEmail());
    }

    @Test
    public void testDelete(){
        Doctor doctor = doctorService.createDoctor(Doctor.builder().name("Abhinav").email("abhi.4125@gmail.com").build());
        Doctor deletedDoctor = doctorService.deleteDoctor(doctor.getId());

        assertNotNull(deletedDoctor);
        assertEquals(doctor.getId(), deletedDoctor.getId());
        assertEquals("Abhinav", deletedDoctor.getName());
        assertEquals("abhi.4125@gmail.com", deletedDoctor.getEmail());
    }

}
