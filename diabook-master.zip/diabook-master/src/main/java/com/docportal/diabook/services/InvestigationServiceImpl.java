package com.docportal.diabook.services;

import com.docportal.diabook.models.Investigation;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InvestigationServiceImpl implements InvestigationService {

    @Override
    public List<Investigation> getAllInvestigations() {
        return null;
    }

    @Override
    public Investigation getInvestigationById(Long id) {
        return null;
    }

    @Override
    public Investigation createInvestigation(Investigation investigation) {
        return null;
    }

    @Override
    public Investigation updateInvestigation(Long id, Investigation investigation) {
        return null;
    }

    @Override
    public Investigation deleteInvestigation(Long id) {
        return null;
    }
}
