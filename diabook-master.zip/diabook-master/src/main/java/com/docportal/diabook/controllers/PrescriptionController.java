package com.docportal.diabook.controllers;

import com.docportal.diabook.models.Prescription;
import com.docportal.diabook.models.Prescription;
import com.docportal.diabook.services.PrescriptionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(PrescriptionController.BASE_URL)
public class PrescriptionController {

    private static final Logger LOGGER = LoggerFactory.getLogger(PrescriptionController.class);
    public static final String BASE_URL = "/doctors/{doctorId}/patients/{patientId}/prescriptions";

    @Autowired
    private PrescriptionService prescriptionService;

    @GetMapping
    private ResponseEntity<List<Prescription>> getPrescriptions(){
        LOGGER.info("received request to get all Prescriptions");
        List<Prescription> response = prescriptionService.getAllPrescriptions();
        LOGGER.info("All Prescriptions: {}", response.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value="{id}")
    private ResponseEntity<Prescription> getPrescriptionById(@PathVariable Long id){
        LOGGER.info("received request to get Prescription by id: {}", id);
        Prescription prescription = prescriptionService.getPrescriptionById(id);
        LOGGER.info("Prescription with id: {} => {}",id, prescription);
        return new ResponseEntity<>(prescription, HttpStatus.OK);
    }

    @PostMapping
    private ResponseEntity<Prescription> addPrescription(@Valid @RequestBody Prescription prescription){
        LOGGER.info("received request to add Prescription with request: {}", prescription);
        Prescription newPrescription= null;
// prescriptionService.createPrescription(prescription);
        LOGGER.info("Added Prescription with request : {}", newPrescription);
        return new ResponseEntity<>(newPrescription, HttpStatus.OK);
    }

    @PutMapping(value="{id}")
    private ResponseEntity<Prescription> updatePrescription(@PathVariable Long id, @Valid @RequestBody Prescription prescription){
        LOGGER.info("received request to updat Prescription with id: {}, Body: {}", id, prescription);
        Prescription newPrescription = null;
// = prescriptionService.updatePrescription(id, prescription);
        LOGGER.info("updated Prescription with id : {} Prescription: {}", id, newPrescription);
        return new ResponseEntity<>(newPrescription, HttpStatus.OK);
    }

    @DeleteMapping(value="{id}")
    private ResponseEntity<Prescription> deletePrescription(@PathVariable Long id){
        LOGGER.info("received request to delete Prescription with id: {}", id);
        Prescription oldPrescription = prescriptionService.deletePrescription(id);
        LOGGER.info("Deleted Prescription with id : {}, docotor: {}", id , oldPrescription);
        return new ResponseEntity<>(oldPrescription, HttpStatus.OK);
    }
}
