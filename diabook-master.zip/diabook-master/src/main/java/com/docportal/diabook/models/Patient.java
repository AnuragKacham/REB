package com.docportal.diabook.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Patient {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;

    private Long drId;
    private String firstName;
    private String lastName;
    private String phone;
    private String email;
    private String address;
    private String dob;
    private String gender;
    private String occupation;
    private String maritalStauts;
    private String education;
    private String deletionFlag;
    private List<Prescription> prescriptions;

//    @CreationTimestamp
//    private LocalDateTime createDateTime;
//
//    @UpdateTimestamp
//    private LocalDateTime updateDateTime;

}
