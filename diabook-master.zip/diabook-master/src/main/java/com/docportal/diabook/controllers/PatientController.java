package com.docportal.diabook.controllers;

import com.docportal.diabook.models.Patient;
import com.docportal.diabook.models.Patient;
import com.docportal.diabook.services.PatientService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(PatientController.BASE_URL)
public class PatientController {

    private static final Logger LOGGER = LoggerFactory.getLogger(PatientController.class);
    public static final String BASE_URL = "/doctors/{doctorId}/patients";

    @Autowired
    private PatientService patientService;

    @GetMapping
    private ResponseEntity<List<Patient>> getPatients(){
        LOGGER.info("received request to get all Patients");
        List<Patient> response = patientService.getAllPatients();
        LOGGER.info("All Patients: {}", response.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value="{id}")
    private ResponseEntity<Patient> getPatientById(@PathVariable Long id){
        LOGGER.info("received request to get Patient by id: {}", id);
        Patient patient = patientService.getPatientById(id);
        LOGGER.info("Patient with id: {} => {}",id, patient);
        return new ResponseEntity<>(patient, HttpStatus.OK);
    }

    @PostMapping
    private ResponseEntity<Patient> addPatient(@Valid @RequestBody Patient patient){
        LOGGER.info("received request to add Patient with request: {}", patient);
        Patient newPatient = patientService.createPatient(patient);
        LOGGER.info("Added Patient with request : {}", newPatient);
        return new ResponseEntity<>(newPatient, HttpStatus.OK);
    }

    @PutMapping(value="{id}")
    private ResponseEntity<Patient> updatePatient(@PathVariable Long id, @Valid @RequestBody Patient patient){
        LOGGER.info("received request to updat Patient with id: {}, Body: {}", id, patient);
        Patient newPatient = patientService.updatePatient(id, patient);
        LOGGER.info("updated Patient with id : {} Patient: {}", id, newPatient);
        return new ResponseEntity<>(newPatient, HttpStatus.OK);
    }

    @DeleteMapping(value="{id}")
    private ResponseEntity<Patient> deletePatient(@PathVariable Long id){
        LOGGER.info("received request to delete Patient with id: {}", id);
        Patient oldPatient = patientService.deletePatient(id);
        LOGGER.info("Deleted Patient with id : {}, docotor: {}", id , oldPatient);
        return new ResponseEntity<>(oldPatient, HttpStatus.OK);
    }
}
