package com.docportal.diabook.services;

import com.docportal.diabook.models.Investigation;

import java.util.List;

public interface InvestigationService {

    List<Investigation> getAllInvestigations();

    Investigation getInvestigationById(Long id);

    Investigation createInvestigation(Investigation investigation);

    Investigation updateInvestigation(Long id, Investigation investigation);

    Investigation deleteInvestigation(Long id);
}
