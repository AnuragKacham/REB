package com.docportal.diabook.services;

import com.docportal.diabook.models.Prescription;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PrescriptionServiceImpl implements PrescriptionService {
    @Override
    public List<Prescription> getAllPrescriptions() {
        return null;
    }

    @Override
    public List<Prescription> getAllPrescriptionsForPatient(Long drId, Long ptId) {
        return null;
    }

    @Override
    public Prescription getPrescriptionById(Long id) {
        return null;
    }

    @Override
    public Prescription createPrescription(Long drId, Long ptId, Prescription prescription) {
        return null;
    }

    @Override
    public Prescription updatePrescription(Long drId, Long ptId, Prescription prescription) {
        return null;
    }

    @Override
    public Prescription deletePrescription(Long id) {
        return null;
    }
}
