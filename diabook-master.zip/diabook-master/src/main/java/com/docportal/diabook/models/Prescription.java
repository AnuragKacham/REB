package com.docportal.diabook.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Prescription {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long rxId;

    private Long drId;
    private Long ptId;
    private String rxHeight;
    private String rxWeight;
    private String rxBmi;
    private String rxWaistCircumference;
    private String rxHipCircumference;
    private String rxWcircumHt;
    private String rxIdealBodyWeight;
    private String rxTargetedBodyWeight;
    private String rxAdvisedCaloriesDay;
    private String rxBloodPressure;
    private String rxCompliants;
    private String rxObservations;
    private String rxDiagnosis;
    private String rxComments;
    private String rxReferredTo;
    private String rxReferredComments;
    private String rxNextVisitDate;
    private String rxNextVisitComment;
    private List<Investigation> investigations;
    private List<Medication> medications;
}
