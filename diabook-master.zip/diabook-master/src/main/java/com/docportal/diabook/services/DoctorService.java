package com.docportal.diabook.services;

import com.docportal.diabook.models.Doctor;

import java.util.List;

public interface DoctorService {

    List<Doctor> getAllDoctors();

    Doctor getDoctorById(Long id);

    Doctor createDoctor(Doctor doctor);

    Doctor updateDoctor(Long id, Doctor doctor);

    Doctor deleteDoctor(Long id);
}
