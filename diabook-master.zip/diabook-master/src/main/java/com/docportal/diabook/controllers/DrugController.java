package com.docportal.diabook.controllers;

import com.docportal.diabook.models.Drug;
import com.docportal.diabook.services.DrugService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(DrugController.BASE_URL)
public class DrugController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DrugController.class);
    public static final String BASE_URL = "/drugs";

    @Autowired
    private DrugService drugService;

    @GetMapping
    private ResponseEntity<List<Drug>> getDrugs(){
        LOGGER.info("received request to get all Drugs");
        List<Drug> response = drugService.getAllDrugs();
        LOGGER.info("All Drugs: {}", response.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value="{id}")
    private ResponseEntity<Drug> getDrugById(@PathVariable Long id){
        LOGGER.info("received request to get Drug by id: {}", id);
        Drug drug = drugService.getDrugById(id);
        LOGGER.info("Drug with id: {} => {}",id, drug);
        return new ResponseEntity<>(drug, HttpStatus.OK);
    }

    @PostMapping
    private ResponseEntity<Drug> addDrug(@Valid @RequestBody Drug drug){
        LOGGER.info("received request to add Drug with request: {}", drug);
        Drug newDrug = drugService.createDrug(drug);
        LOGGER.info("Added Drug with request : {}", newDrug);
        return new ResponseEntity<>(newDrug, HttpStatus.OK);
    }

    @PutMapping(value="{id}")
    private ResponseEntity<Drug> updateDrug(@PathVariable Long id, @Valid @RequestBody Drug drug){
        LOGGER.info("received request to updat Drug with id: {}, Body: {}", id, drug);
        Drug newDrug = drugService.updateDrug(id, drug);
        LOGGER.info("updated Drug with id : {} Drug: {}", id, newDrug);
        return new ResponseEntity<>(newDrug, HttpStatus.OK);
    }

    @DeleteMapping(value="{id}")
    private ResponseEntity<Drug> deleteDrug(@PathVariable Long id){
        LOGGER.info("received request to delete Drug with id: {}", id);
        Drug oldDrug = drugService.deleteDrug(id);
        LOGGER.info("Deleted Drug with id : {}, docotor: {}", id , oldDrug);
        return new ResponseEntity<>(oldDrug, HttpStatus.OK);
    }
}
