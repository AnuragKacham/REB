package com.docportal.diabook.entities;

import com.docportal.diabook.entities.utils.BaseEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "patients")
@SequenceGenerator(initialValue = 1, name="idgen", sequenceName = "patientseq", allocationSize = 1)
public class PatientEntity extends BaseEntity {

    private Long id;
    private Long drId;

    @OneToMany(mappedBy = "ptId")
    private List<PrescriptionEntity> prescriptionEntities;

    private String firstName;
    private String lastName;
    private String phone;
    private String email;
    private String address;
    private String dob;
    private String gender;
    private String occupation;
    private String maritalStauts;
    private String education;
    private String deletionFlag;

}