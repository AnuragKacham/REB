package com.docportal.diabook.services;

import com.docportal.diabook.models.Patient;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientServiceImpl implements PatientService {


    @Override
    public List<Patient> getAllPatients() {
        return null;
    }

    @Override
    public Patient getPatientById(Long Id) {
        return null;
    }

    @Override
    public Patient createPatient(Patient patient) {
        return null;
    }

    @Override
    public Patient updatePatient(Long id, Patient patient) {
        return null;
    }

    @Override
    public Patient deletePatient(Long id) {
        return null;
    }
}
