package com.docportal.diabook.entities;

import com.docportal.diabook.entities.utils.BaseEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "prescriptions")
@SequenceGenerator(initialValue = 1, name = "idgen", sequenceName = "prescriptionseq", allocationSize = 1)
public class PrescriptionEntity extends BaseEntity {

    private Long id;
    private Long drId;
    private Long ptId;
    private String rxHeight;
    private String rxWeight;
    private String rxBmi;
    private String rxWaistCircumference;
    private String rxHipCircumference;
    private String rxWcircumHt;
    private String rxIdealBodyWeight;
    private String rxTargetedBodyWeight;
    private String rxAdvisedCaloriesDay;
    private String rxBloodPressure;
    private String rxCompliants;
    private String rxObservations;
    private String rxDiagnosis;
    private String rxComments;
    private String rxReferredTo;
    private String rxReferredComments;
    private String rxNextVisitDate;
    private String rxNextVisitComment;

    @OneToMany(mappedBy = "rxId")
    private List<InvestigationEntity>  investigationEntities;

    @OneToMany(mappedBy = "rxId")
    private List<MedicationEntity> medicationEntities;

}
