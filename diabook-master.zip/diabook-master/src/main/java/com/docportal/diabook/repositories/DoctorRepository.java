package com.docportal.diabook.repositories;

import com.docportal.diabook.entities.DoctorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DoctorRepository extends JpaRepository<DoctorEntity, Long> {
    @Query("select t from DoctorEntity t")
    List<DoctorEntity> getDoctorEntities();
}
