package com.docportal.diabook.entities;

import com.docportal.diabook.entities.utils.BaseEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;


import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name= "doctors", uniqueConstraints = {@UniqueConstraint(columnNames = {"id"})})
@SequenceGenerator(initialValue = 1, name = "idgen", sequenceName = "doctorseq", allocationSize = 1)
public class DoctorEntity extends BaseEntity {

    private  Long id;

    @NotNull
    @Size(max=50)
    private String name;

    @NotNull
    private String email;

    @OneToMany(mappedBy = "drId")
    private List<PatientEntity> patientEntities;
}
