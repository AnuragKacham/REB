package com.docportal.diabook.services;

import com.docportal.diabook.models.Patient;

import java.util.List;

public interface PatientService {

    List<Patient> getAllPatients();

    Patient getPatientById(Long Id);

    Patient createPatient(Patient patient);

    Patient updatePatient(Long id, Patient patient);

    Patient deletePatient(Long id);
}
