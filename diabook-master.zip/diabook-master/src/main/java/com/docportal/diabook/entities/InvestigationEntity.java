package com.docportal.diabook.entities;

import com.docportal.diabook.entities.utils.BaseEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "investigations")
@SequenceGenerator(initialValue = 1, name="idgen", sequenceName = "investigationseq", allocationSize = 1)
public class InvestigationEntity extends BaseEntity {

    private Long id;
    private Long drId;
    private Long ptId;
    private Long rxId;
    private String name;
    private String comments;
    private String deletionFlag;
}
