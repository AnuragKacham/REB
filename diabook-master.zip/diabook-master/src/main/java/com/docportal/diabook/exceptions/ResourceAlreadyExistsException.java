package com.docportal.diabook.exceptions;

public class ResourceAlreadyExistsException extends ResourceException {
    public ResourceAlreadyExistsException(String message) {
        super(message);
    }
}
