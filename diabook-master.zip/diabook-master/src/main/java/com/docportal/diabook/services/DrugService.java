package com.docportal.diabook.services;

import com.docportal.diabook.models.Drug;

import java.util.List;

public interface DrugService {

    List<Drug> getAllDrugs();

    Drug getDrugById(Long id);

    Drug createDrug(Drug drug);

    Drug updateDrug(Long id, Drug drug);

    Drug deleteDrug(Long id);
}
