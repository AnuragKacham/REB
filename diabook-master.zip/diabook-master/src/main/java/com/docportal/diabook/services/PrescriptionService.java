package com.docportal.diabook.services;

import com.docportal.diabook.models.Prescription;

import java.util.List;

public interface PrescriptionService {

    List<Prescription> getAllPrescriptions();

    List<Prescription> getAllPrescriptionsForPatient(Long drId, Long ptId);

    Prescription getPrescriptionById(Long id);

    Prescription createPrescription(Long drId, Long ptId, Prescription prescription);

    Prescription updatePrescription(Long drId, Long ptId, Prescription prescription);

    Prescription deletePrescription(Long id);
}
