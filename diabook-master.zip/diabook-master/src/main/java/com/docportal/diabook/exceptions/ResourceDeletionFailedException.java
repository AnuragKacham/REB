package com.docportal.diabook.exceptions;

public class ResourceDeletionFailedException extends ResourceException {
    public ResourceDeletionFailedException(String message) {
        super(message);
    }

    public ResourceDeletionFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}
