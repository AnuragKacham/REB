package com.docportal.diabook.translators;

public interface Translator<E, M> {
    E toEntity(M model);
    M toModel(E entity);
}
