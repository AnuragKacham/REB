package com.docportal.diabook.exceptions;

public class ResourceCreationFailedException extends ResourceException {
    public ResourceCreationFailedException(String message) {
        super(message);
    }

    public ResourceCreationFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}
