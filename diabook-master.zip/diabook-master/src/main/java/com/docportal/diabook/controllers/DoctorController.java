package com.docportal.diabook.controllers;

import com.docportal.diabook.models.Doctor;
import com.docportal.diabook.services.DoctorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(DoctorController.BASE_URL)
public class DoctorController {
    private static final Logger LOGGER = LoggerFactory.getLogger(DoctorController.class);
    public static final String BASE_URL = "/doctors";

    @Autowired
    private DoctorService doctorService;

    @GetMapping
    private ResponseEntity<List<Doctor>> getDoctors(){
        LOGGER.info("received request to get all doctors");
        List<Doctor> response = doctorService.getAllDoctors();
        LOGGER.info("All Doctors: {}", response.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value="{id}")
    private ResponseEntity<Doctor> getDoctorById(@PathVariable Long id){
        LOGGER.info("received request to get doctor by id: {}", id);
        Doctor doctor = doctorService.getDoctorById(id);
        LOGGER.info("Doctor with id: {} => {}",id, doctor);
        return new ResponseEntity<>(doctor, HttpStatus.OK);
    }

    @PostMapping
    private ResponseEntity<Doctor> addDoctor(@Valid @RequestBody Doctor doctor){
        LOGGER.info("received request to add doctor with request: {}", doctor);
        Doctor newDoctor = doctorService.createDoctor(doctor);
        LOGGER.info("Added Doctor with request : {}", newDoctor);
        return new ResponseEntity<>(newDoctor, HttpStatus.OK);
    }

    @PutMapping(value="{id}")
    private ResponseEntity<Doctor> updateDoctor(@PathVariable Long id, @Valid @RequestBody Doctor doctor){
        LOGGER.info("received request to updat Doctor with id: {}, Body: {}", id, doctor);
        Doctor newDoctor = doctorService.updateDoctor(id, doctor);
        LOGGER.info("updated Doctor with id : {} doctor: {}", id, newDoctor);
        return new ResponseEntity<>(newDoctor, HttpStatus.OK);
    }

    @DeleteMapping(value="{id}")
    private ResponseEntity<Doctor> deleteDoctor(@PathVariable Long id){
        LOGGER.info("received request to delete doctor with id: {}", id);
        Doctor oldDoctor = doctorService.deleteDoctor(id);
        LOGGER.info("Deleted Doctor with id : {}, docotor: {}", id , oldDoctor);
        return new ResponseEntity<>(oldDoctor, HttpStatus.OK);
    }

}
