package com.docportal.diabook.controllers;

import com.docportal.diabook.models.Investigation;
import com.docportal.diabook.models.Investigation;
import com.docportal.diabook.services.InvestigationService;
import com.docportal.diabook.services.InvestigationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(InvestigationController.BASE_URL)
public class InvestigationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(InvestigationController.class);
    public static final String BASE_URL = "/investigations";

    @Autowired
    private InvestigationService investigationService;

    @GetMapping
    private ResponseEntity<List<Investigation>> getInvestigations(){
        LOGGER.info("received request to get all Investigations");
        List<Investigation> response = investigationService.getAllInvestigations();
        LOGGER.info("All Investigations: {}", response.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value="{id}")
    private ResponseEntity<Investigation> getInvestigationById(@PathVariable Long id){
        LOGGER.info("received request to get Investigation by id: {}", id);
        Investigation investigation = investigationService.getInvestigationById(id);
        LOGGER.info("Investigation with id: {} => {}",id, investigation);
        return new ResponseEntity<>(investigation, HttpStatus.OK);
    }

    @PostMapping
    private ResponseEntity<Investigation> addInvestigation(@Valid @RequestBody Investigation investigation){
        LOGGER.info("received request to add Investigation with request: {}", investigation);
        Investigation newInvestigation = investigationService.createInvestigation(investigation);
        LOGGER.info("Added Investigation with request : {}", newInvestigation);
        return new ResponseEntity<>(newInvestigation, HttpStatus.OK);
    }

    @PutMapping(value="{id}")
    private ResponseEntity<Investigation> updateInvestigation(@PathVariable Long id, @Valid @RequestBody Investigation investigation){
        LOGGER.info("received request to updat Investigation with id: {}, Body: {}", id, investigation);
        Investigation newInvestigation = investigationService.updateInvestigation(id, investigation);
        LOGGER.info("updated Investigation with id : {} Investigation: {}", id, newInvestigation);
        return new ResponseEntity<>(newInvestigation, HttpStatus.OK);
    }

    @DeleteMapping(value="{id}")
    private ResponseEntity<Investigation> deleteInvestigation(@PathVariable Long id){
        LOGGER.info("received request to delete Investigation with id: {}", id);
        Investigation oldInvestigation = investigationService.deleteInvestigation(id);
        LOGGER.info("Deleted Investigation with id : {}, docotor: {}", id , oldInvestigation);
        return new ResponseEntity<>(oldInvestigation, HttpStatus.OK);
    }
}
