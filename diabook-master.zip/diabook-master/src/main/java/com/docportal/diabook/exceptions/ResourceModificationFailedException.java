package com.docportal.diabook.exceptions;

public class ResourceModificationFailedException extends ResourceException {
    public ResourceModificationFailedException(String message) {
        super(message);
    }

    public ResourceModificationFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}
