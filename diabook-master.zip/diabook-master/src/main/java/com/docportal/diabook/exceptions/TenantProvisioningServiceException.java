package com.docportal.diabook.exceptions;

import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * @author sank
 */
@Getter
public class TenantProvisioningServiceException extends RuntimeException {

    private HttpStatus httpStatus;

    public TenantProvisioningServiceException(HttpStatus httpStatus, String message) {
        super(message);
        this.httpStatus = httpStatus;
    }
}
