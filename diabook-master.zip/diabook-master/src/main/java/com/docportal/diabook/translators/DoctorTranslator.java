package com.docportal.diabook.translators;

import com.docportal.diabook.entities.DoctorEntity;
import com.docportal.diabook.models.Doctor;
import org.springframework.stereotype.Component;

@Component
public class DoctorTranslator implements Translator<DoctorEntity, Doctor>{
    @Override
    public DoctorEntity toEntity(Doctor doctorModel){
        return DoctorEntity.builder()
                .id(doctorModel.getId())
                .name(doctorModel.getName())
                .email(doctorModel.getEmail()).build();
    }

    @Override
    public Doctor toModel(DoctorEntity doctorEntity){
        return Doctor.builder()
                .id(doctorEntity.getId())
                .name(doctorEntity.getName())
                .email(doctorEntity.getEmail()).build();
    }
}
