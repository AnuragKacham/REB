package com.docportal.diabook.models;

import com.google.common.base.Function;
import lombok.AllArgsConstructor;
import lombok.Getter;

public class Defaults {
    public static final String ASYNC_THREAD_NAME = "DOCTOR-PORTAL";
    public static final Function<String, Function<String, String>> RESOURCE_CREATION_FAILED = resourceType -> (Function<String, String>) resourceName -> String.format("Failed to create %s with name : %s", resourceType, resourceName);
    public static final Function<String, Function<String, String>> RESOURCE_DELETION_FAILED = resourceType -> (Function<String, String>) resourceName -> String.format("Failed to delete %s with id : %s", resourceType, resourceName);
    public static final Function<String, Function<String, String>> RESOURCE_MODIFICATION_FAILED = resourceType -> (Function<String, String>) resourceName -> String.format("Failed to modify %s with id : %s", resourceType, resourceName);
    public static final Function<String, Function<String, String>> RESOURCE_NOT_FOUND = resourceType -> (Function<String, String>) resourceId -> String.format("Could not find %s with id = '%s'", resourceType, resourceId);

    @AllArgsConstructor
    @Getter
    public enum STATUS {
        ACTIVE("ACTIVE"),
        INACTIVE("INACTIVE"),
        PENDING("PENDING"),
        REGISTERED("REGISTERED");

        private String text;
    }

    @AllArgsConstructor
    @Getter
    public enum DRUG_STATUS {
        BANNED("BANNED"),
        IN_STOCK("IN_STOCK"),
        OUT_OF_STOCK("OUT_OF_STOCK");

        private String text;
    }


}
