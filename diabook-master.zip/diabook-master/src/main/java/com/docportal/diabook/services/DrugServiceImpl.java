package com.docportal.diabook.services;

import com.docportal.diabook.models.Defaults;
import com.docportal.diabook.models.Drug;
import com.google.common.base.Function;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DrugServiceImpl implements DrugService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DrugServiceImpl.class);

    private static final Function<String, String> DDOCTOR_NOT_FOUND = Defaults.RESOURCE_NOT_FOUND.apply("drug");
    private static final Function<String , String> DOCTOR_MODIFICATION_FAILED = Defaults.RESOURCE_MODIFICATION_FAILED.apply("drug");
    private static final Function<String, String> DOCTOR_CREATION_FAILED = Defaults.RESOURCE_CREATION_FAILED.apply("drug");
    private static final Function<String, String> DOCTOR_DELETION_FAILED = Defaults.RESOURCE_DELETION_FAILED.apply("drug");


    @Override
    public List<Drug> getAllDrugs() {
        return null;
    }

    @Override
    public Drug getDrugById(Long drugId) {
        return null;
    }

    @Override
    public Drug createDrug(Drug drug) {
        return null;
    }

    @Override
    public Drug updateDrug(Long drugId, Drug drug) {
        return null;
    }

    @Override
    public Drug deleteDrug(Long drugId) {
        return null;
    }
}
