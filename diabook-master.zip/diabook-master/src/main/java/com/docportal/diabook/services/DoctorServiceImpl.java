package com.docportal.diabook.services;

import com.docportal.diabook.entities.DoctorEntity;
import com.docportal.diabook.exceptions.ResourceCreationFailedException;
import com.docportal.diabook.exceptions.ResourceDeletionFailedException;
import com.docportal.diabook.exceptions.ResourceNotFoundException;
import com.docportal.diabook.models.Defaults;
import com.docportal.diabook.models.Doctor;
import com.docportal.diabook.repositories.DoctorRepository;
import com.docportal.diabook.translators.DoctorTranslator;
import com.google.common.base.Function;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DoctorServiceImpl implements DoctorService{

    private static final Logger LOGGER = LoggerFactory.getLogger(DoctorServiceImpl.class);

    private static final Function<String, String> DDOCTOR_NOT_FOUND = Defaults.RESOURCE_NOT_FOUND.apply("doctor");
    private static final Function<String , String> DOCTOR_MODIFICATION_FAILED = Defaults.RESOURCE_MODIFICATION_FAILED.apply("doctor");
    private static final Function<String, String> DOCTOR_CREATION_FAILED = Defaults.RESOURCE_CREATION_FAILED.apply("doctor");
    private static final Function<String, String> DOCTOR_DELETION_FAILED = Defaults.RESOURCE_DELETION_FAILED.apply("doctor");

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private DoctorTranslator doctorTranslator;

    @Override
    public List<Doctor> getAllDoctors(){
        Collection<DoctorEntity> doctorEntities = doctorRepository.getDoctorEntities();
        return doctorEntities.stream().map(doctorEntity -> doctorTranslator.toModel(doctorEntity)).collect(Collectors.toList());
    }

    @Override
    public Doctor getDoctorById(Long id){
        // Note this is an optional, we  need to use .get() to return.
        Optional<DoctorEntity> doctorEntity = doctorRepository.findById(id);
        if(doctorEntity.isPresent()){
            return doctorTranslator.toModel(doctorEntity.get());
        }else {
            throw new ResourceNotFoundException(DDOCTOR_NOT_FOUND.apply(id.toString()));
        }
    }

    @Override
    public Doctor createDoctor(Doctor doctor) {
        try{
            DoctorEntity doctorEntity = doctorRepository.save(doctorTranslator.toEntity(doctor));
            return doctorTranslator.toModel(doctorEntity);
        }catch(Exception e){
            throw new ResourceCreationFailedException(DOCTOR_CREATION_FAILED.apply(doctor.getName()), e);
        }
    }

    @Override
    public Doctor updateDoctor(Long id, Doctor doctor){
        Optional<DoctorEntity> doctorById = doctorRepository.findById(id);

        if (doctorById.isPresent()){
            DoctorEntity doctorEntity = doctorById.get();

            doctorEntity.setEmail(doctor.getEmail());
            doctorEntity.setName(doctor.getName());

            DoctorEntity modifiedDoctor = doctorRepository.save(doctorEntity);
            return doctorTranslator.toModel(modifiedDoctor);
        }else {
            throw new ResourceNotFoundException(DDOCTOR_NOT_FOUND.apply(id.toString()));
        }
    }

    @Override
    public Doctor deleteDoctor(Long id){
        Optional<DoctorEntity> doctorById = doctorRepository.findById(id);

        if (doctorById.isPresent()){
            try{
                doctorRepository.deleteById(id);
                doctorRepository.flush();
            } catch(Exception e){
                throw new ResourceDeletionFailedException(DOCTOR_DELETION_FAILED.apply(id.toString()), e);
            }
            return doctorTranslator.toModel(doctorById.get());
        }else {
            throw new ResourceNotFoundException(DDOCTOR_NOT_FOUND.apply(id.toString()));
        }
    }
}
